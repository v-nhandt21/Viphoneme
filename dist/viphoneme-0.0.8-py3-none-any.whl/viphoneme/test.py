from __init__ import vi2IPA_split, syms
print(vi2IPA_split("","/"))